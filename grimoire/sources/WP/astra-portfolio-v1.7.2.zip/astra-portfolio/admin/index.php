<?php
/**
 * Index file
 *
 * @package Astra Portfolio
 * @since Astra Portfolio 1.0.0
 */

/* Silence is golden, and we agree. */

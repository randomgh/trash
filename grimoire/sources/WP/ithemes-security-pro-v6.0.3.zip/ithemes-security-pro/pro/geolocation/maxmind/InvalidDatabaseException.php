<?php

/**
 * This class should be thrown when unexpected data is found in the database.
 */
class ITSEC_MaxMind_DB_InvalidDatabaseException extends \Exception
{
}

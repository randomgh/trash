=== WooCommerce Google Analytics Pro ===
Author: skyverge
Tags: woocommerce
Requires at least: 4.4
Tested up to: 4.9.7

Supercharge your Google Analytics tracking with enhanced eCommerce tracking and custom event tracking

See http://docs.woothemes.com/document/woocommerce-google-analytics-pro/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-google-analytics-pro' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
